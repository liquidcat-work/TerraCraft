import { useEffect } from "react";

const Index = () => {
  useEffect(() => {
    window.location.replace("/game/index.html");
  }, []);
  return null;
};

export default Index;
